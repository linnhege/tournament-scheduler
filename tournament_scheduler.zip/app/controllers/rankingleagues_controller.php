<?php

class RankingleaguesController extends MvcPublicController {
	
}

?>