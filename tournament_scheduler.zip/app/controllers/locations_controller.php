<?php

class locationsController extends MvcPublicController {
	
}

?>