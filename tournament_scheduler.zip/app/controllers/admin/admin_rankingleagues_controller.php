<?php

class AdminRankingleaguesController extends MvcAdminController {
	
	var $default_columns = array('name', 'details');
	
}

?>