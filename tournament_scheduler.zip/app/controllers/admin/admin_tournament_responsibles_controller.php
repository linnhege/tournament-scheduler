<?php

class AdminTournamentResponsiblesController extends MvcAdminController {
	
	var $default_columns = array('id', 'name');
	
}

?>