<?php

class AdminLocationsController extends MvcAdminController {
	
	var $default_columns = array('id', 'name');
	
}

?>