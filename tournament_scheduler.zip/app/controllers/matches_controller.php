<?php

class MatchesController extends MvcPublicController {
	
}

?>