<?php

class TeamsController extends MvcPublicController {
	
}

?>