<?php

class Rankingleague extends MvcModel {

	var $display_field = 'name';
    var $has_many = array('Series');
}

?>