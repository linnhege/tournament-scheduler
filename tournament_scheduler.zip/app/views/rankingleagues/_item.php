<div>
	<?php echo $this->html->rankingleague_link($tournament); ?></div>