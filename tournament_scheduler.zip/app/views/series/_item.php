<div>
	<?php echo $this->html->series_link($object); ?></div>