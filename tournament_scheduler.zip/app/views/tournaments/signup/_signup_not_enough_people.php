<p>
    Det er ingen tilgjenglige spiller for deg å spille med. Hvis du har en partner som ikke er registert,
    få personen til å <a href='<?php echo wp_login_url($_SERVER["REQUEST_URI"]) ?>'> registere seg </a>
</p>
