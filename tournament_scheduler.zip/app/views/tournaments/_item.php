<div>
	<?php echo $this->html->tournament_link($object); ?>
</div>